package com.example.llmlab

object Native {
    var ok = false
    init { try { System.loadLibrary("llmnative"); ok = true } catch (e: Throwable) { } }
    external fun create(L: Int, d: Int, H: Int, T: Int, seed: Int, threads: Int)
    external fun setThreads(n: Int)
    external fun setState(step: Long, seen: Long)
    external fun conf(B: Int, lr: Float, live: Boolean, mix: Float)
    external fun start()
    external fun stop()
    external fun resetOpt()
    external fun feed(b: ByteArray)
    external fun data(b: ByteArray, first: Boolean)
    external fun stat(): String
    external fun gen(ctx: ByteArray, temp: Float, k: Int): Int
    external fun wsize(): Int
    external fun getW(off: Int, len: Int): ByteArray
    external fun setW(off: Int, b: ByteArray)
}
