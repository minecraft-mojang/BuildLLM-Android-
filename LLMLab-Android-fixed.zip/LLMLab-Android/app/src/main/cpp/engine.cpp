// Native CPU transformer trainer: same architecture/param layout as the JS version (byte vocab, no linear biases,
// pre-LN, GELU~x*sigmoid(1.702x), tied output embedding). Multithreaded, auto-vectorised (NEON on arm64).
#include <vector>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <cmath>
#include <cstring>
#include <cstdint>
#include <algorithm>
#include <random>
#include <chrono>
#include <string>
#include <numeric>
#ifdef LLM_JNI
#include <jni.h>
#endif
typedef float f32;

struct Pool {
  int n = 1; std::vector<std::thread> th; std::mutex m; std::condition_variable cv, cd;
  const std::function<void(int,int)>* job = nullptr; std::atomic<int> next{0}; int total = 0, chunk = 1, active = 0; long gen = 0; bool stop = false;
  void work() { for (;;) { int i = next.fetch_add(chunk); if (i >= total) break; (*job)(i, std::min(total, i + chunk)); } }
  void loop() { long seen = 0; for (;;) {
      { std::unique_lock<std::mutex> lk(m); cv.wait(lk, [&]{ return stop || gen != seen; }); if (stop) return; seen = gen; }
      work(); { std::lock_guard<std::mutex> lk(m); if (--active == 0) cd.notify_one(); } } }
  void start(int nt) { stopAll(); n = std::max(1, std::min(nt, 16)); stop = false; gen = 0; for (int i = 1; i < n; i++) th.emplace_back([this]{ loop(); }); }
  void stopAll() { { std::lock_guard<std::mutex> lk(m); stop = true; } cv.notify_all(); for (auto& t : th) t.join(); th.clear(); n = 1; }
  void run(int tot, int ch, const std::function<void(int,int)>& f) {
    if (n == 1 || tot <= ch) { f(0, tot); return; }
    { std::lock_guard<std::mutex> lk(m); job = &f; total = tot; chunk = ch; next = 0; active = n - 1; gen++; }
    cv.notify_all(); work(); std::unique_lock<std::mutex> lk(m); cd.wait(lk, [&]{ return active == 0; }); }
  ~Pool() { stopAll(); }
};

struct Cfg { int L = 0, d = 0, H = 0, T = 0, V = 256; };
struct Layer { std::vector<f32> h1, xh1, inv1, qkv, P, ao, xh2, inv2, h2, m1, s, a; };
struct Acts {
  int B = 0, T = 0; std::vector<f32> x, tmp, hf, xhf, invf, logits, rl, dx, tA, tB, dqkv; std::vector<Layer> ly;
  void alloc(int B_, int T_, const Cfg& c) {
    B = B_; T = T_; size_t N = (size_t)B * T, d = c.d, H = c.H;
    x.assign(N*d,0); tmp.assign(N*d,0); hf.assign(N*d,0); xhf.assign(N*d,0); invf.assign(N,0); logits.assign(N*c.V,0); rl.assign(N,0);
    dx.assign(N*d,0); tA.assign(N*4*d,0); tB.assign(N*d,0); dqkv.assign(N*3*d,0); ly.assign(c.L, Layer());
    for (auto& y : ly) { y.h1.assign(N*d,0); y.xh1.assign(N*d,0); y.inv1.assign(N,0); y.qkv.assign(N*3*d,0); y.P.assign((size_t)B*H*T*T,0);
      y.ao.assign(N*d,0); y.xh2.assign(N*d,0); y.inv2.assign(N,0); y.h2.assign(N*d,0); y.m1.assign(N*4*d,0); y.s.assign(N*4*d,0); y.a.assign(N*4*d,0); }
  }
};

struct Eng {
  Cfg c; int V = 256; std::vector<f32> w, g, m, v; size_t o_te = 0, o_pe = 0, o_gf = 0, o_bf = 0, total = 0;
  struct LO { size_t g1, b1, qkv, o, g2, b2, w1, w2; }; std::vector<LO> lo;
  long adamT = 0; Pool pool; std::mutex mu; Acts ta, ia;
  std::thread th; std::atomic<bool> running{false}; std::atomic<int> Bset{8}; std::atomic<float> lrset{.003f}, mixp{.15f}; std::atomic<bool> live{true}; std::atomic<int> pausing{0}; /* >0: other threads want `mu`; trainer yields between steps so they never starve */
  struct Pause { Eng& e; Pause(Eng& x) : e(x) { e.pausing++; } ~Pause() { e.pausing--; } };
  std::atomic<long> step{0}, seen{0}; std::atomic<int> epoch{0};
  std::mutex dm; std::vector<uint16_t> corpus, lq; /* token ids (bytes when V=256) */ size_t lpos = 0;
  std::mutex sm; std::vector<float> lossq; std::vector<double> times; std::string err;
  uint64_t rs = 88172645463325252ULL;
  uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
  float rf() { return (rnd() >> 40) * (1.0f / 16777216.0f); }
  ~Eng() { stop(); pool.stopAll(); }

  template<class F> void pf(int tot, int ch, F&& f) { std::function<void(int,int)> fn(std::forward<F>(f)); pool.run(tot, ch, fn); }

  void create(int L, int d, int H, int T, int Vv, int seed, int thr) {
    stop(); std::lock_guard<std::mutex> lk(mu);
    V = Vv; c = {L, d, H, T, Vv}; { std::lock_guard<std::mutex> l3(dm); lq.clear(); corpus.clear(); lpos = 0; } size_t o = 0; auto take = [&](size_t n) { size_t r = o; o += n; return r; };
    o_te = take((size_t)V*d); o_pe = take((size_t)T*d); lo.assign(L, LO());
    for (int l = 0; l < L; l++) { LO& q = lo[l]; q.g1 = take(d); q.b1 = take(d); q.qkv = take((size_t)d*3*d); q.o = take((size_t)d*d); q.g2 = take(d); q.b2 = take(d); q.w1 = take((size_t)d*4*d); q.w2 = take((size_t)4*d*d); }
    o_gf = take(d); o_bf = take(d); total = o;
    w.assign(total,0); g.assign(total,0); m.assign(total,0); v.assign(total,0); adamT = 0;
    std::mt19937 rg(seed); std::normal_distribution<float> nd(0, 1);
    auto N_ = [&](size_t off, size_t n, float sd) { for (size_t i = 0; i < n; i++) w[off+i] = nd(rg) * sd; };
    auto O_ = [&](size_t off, size_t n) { for (size_t i = 0; i < n; i++) w[off+i] = 1; };
    N_(o_te, (size_t)V*d, .02f); N_(o_pe, (size_t)T*d, .01f); float s2 = .02f / std::sqrt(2.f * L);
    for (int l = 0; l < L; l++) { LO& q = lo[l]; O_(q.g1, d); N_(q.qkv, (size_t)d*3*d, .02f); N_(q.o, (size_t)d*d, s2); O_(q.g2, d); N_(q.w1, (size_t)d*4*d, .02f); N_(q.w2, (size_t)4*d*d, s2); }
    O_(o_gf, d); ta = Acts(); ia = Acts(); ia.alloc(1, T, c); pool.start(thr); step = 0; seen = 0; epoch++;
    { std::lock_guard<std::mutex> l2(sm); lossq.clear(); times.clear(); err.clear(); }
  }

  // ---- GEMMs (row-major) ----
  void gemm_nn(int M, int N, int K, const f32* A, const f32* B, f32* C, bool acc) { // C[M,N] (+)= A[M,K] B[K,N]
    pf((M+3)/4, 2, [&](int b0, int b1) { for (int bi = b0; bi < b1; bi++) { int i0 = bi*4, r = std::min(4, M-i0);
      if (!acc) for (int t = 0; t < r; t++) memset(C + (size_t)(i0+t)*N, 0, (size_t)N*4);
      if (r == 4) { f32 *__restrict c0 = C+(size_t)i0*N, *__restrict c1 = c0+N, *__restrict c2 = c1+N, *__restrict c3 = c2+N;
        for (int k = 0; k < K; k++) { const f32* __restrict b = B+(size_t)k*N; f32 a0 = A[(size_t)i0*K+k], a1 = A[(size_t)(i0+1)*K+k], a2 = A[(size_t)(i0+2)*K+k], a3 = A[(size_t)(i0+3)*K+k];
          for (int j = 0; j < N; j++) { f32 bj = b[j]; c0[j] += a0*bj; c1[j] += a1*bj; c2[j] += a2*bj; c3[j] += a3*bj; } } }
      else for (int t = 0; t < r; t++) { f32* __restrict ct = C+(size_t)(i0+t)*N; for (int k = 0; k < K; k++) { const f32* __restrict b = B+(size_t)k*N; f32 a = A[(size_t)(i0+t)*K+k]; for (int j = 0; j < N; j++) ct[j] += a*b[j]; } } } });
  }
  void gemm_nt(int M, int N, int K, const f32* A, const f32* Bt, f32* C, bool acc) { // C[M,N] (+)= A[M,K] Bt[N,K]^T
    pf(M, 4, [&](int r0, int r1) { for (int i = r0; i < r1; i++) { const f32* __restrict a = A+(size_t)i*K; f32* ci = C+(size_t)i*N; int j = 0;
      for (; j+4 <= N; j += 4) { const f32 *__restrict b0 = Bt+(size_t)j*K, *__restrict b1 = b0+K, *__restrict b2 = b1+K, *__restrict b3 = b2+K; f32 s0 = 0, s1 = 0, s2 = 0, s3 = 0;
        for (int k = 0; k < K; k++) { f32 ak = a[k]; s0 += ak*b0[k]; s1 += ak*b1[k]; s2 += ak*b2[k]; s3 += ak*b3[k]; }
        if (acc) { ci[j] += s0; ci[j+1] += s1; ci[j+2] += s2; ci[j+3] += s3; } else { ci[j] = s0; ci[j+1] = s1; ci[j+2] = s2; ci[j+3] = s3; } }
      for (; j < N; j++) { const f32* __restrict b = Bt+(size_t)j*K; f32 s = 0; for (int k = 0; k < K; k++) s += a[k]*b[k]; if (acc) ci[j] += s; else ci[j] = s; } } });
  }
  void gemm_tn(int M, int K, int N, const f32* A, const f32* D, f32* C) { // C[K,N] += A[M,K]^T D[M,N]
    pf((K+3)/4, 1, [&](int b0, int b1) { for (int bi = b0; bi < b1; bi++) { int k0 = bi*4, r = std::min(4, K-k0);
      if (r == 4) { f32 *__restrict c0 = C+(size_t)k0*N, *__restrict c1 = c0+N, *__restrict c2 = c1+N, *__restrict c3 = c2+N;
        for (int i = 0; i < M; i++) { const f32* __restrict d = D+(size_t)i*N; const f32* ar = A+(size_t)i*K+k0; f32 a0 = ar[0], a1 = ar[1], a2 = ar[2], a3 = ar[3];
          for (int j = 0; j < N; j++) { f32 dj = d[j]; c0[j] += a0*dj; c1[j] += a1*dj; c2[j] += a2*dj; c3[j] += a3*dj; } } }
      else for (int t = 0; t < r; t++) { f32* __restrict ct = C+(size_t)(k0+t)*N; for (int i = 0; i < M; i++) { const f32* __restrict d = D+(size_t)i*N; f32 a = A[(size_t)i*K+k0+t]; for (int j = 0; j < N; j++) ct[j] += a*d[j]; } } } });
  }
  // ---- LayerNorm ----
  void ln_fwd(const f32* x, const f32* ga, const f32* be, f32* xh, f32* inv, f32* out, int N, int d) {
    pf(N, 16, [&](int r0, int r1) { for (int r = r0; r < r1; r++) { const f32* xr = x+(size_t)r*d; f32 mu_ = 0; for (int i = 0; i < d; i++) mu_ += xr[i]; mu_ /= d;
      f32 var = 0; for (int i = 0; i < d; i++) { f32 t = xr[i]-mu_; var += t*t; } var /= d; f32 iv = 1.f/std::sqrt(var+1e-5f); inv[r] = iv;
      f32* xo = xh+(size_t)r*d; f32* oo = out+(size_t)r*d; for (int i = 0; i < d; i++) { f32 h = (xr[i]-mu_)*iv; xo[i] = h; oo[i] = h*ga[i]+be[i]; } } });
  }
  void ln_bwd(const f32* dy, const f32* xh, const f32* inv, const f32* ga, f32* dg, f32* db, f32* dx, int N, int d) {
    pf(N, 16, [&](int r0, int r1) { for (int r = r0; r < r1; r++) { const f32* dyr = dy+(size_t)r*d; const f32* xr = xh+(size_t)r*d; f32 s1 = 0, s2 = 0;
      for (int i = 0; i < d; i++) { f32 t = dyr[i]*ga[i]; s1 += t; s2 += t*xr[i]; } s1 /= d; s2 /= d; f32* o = dx+(size_t)r*d; f32 iv = inv[r];
      for (int i = 0; i < d; i++) o[i] += iv*(dyr[i]*ga[i] - s1 - xr[i]*s2); } });
    for (int r = 0; r < N; r++) { const f32* dyr = dy+(size_t)r*d; const f32* xr = xh+(size_t)r*d; for (int i = 0; i < d; i++) { dg[i] += dyr[i]*xr[i]; db[i] += dyr[i]; } }
  }
  void add_inplace(f32* x, const f32* y, size_t n) { pf((int)((n+8191)/8192), 1, [&](int b0, int b1) { size_t s = (size_t)b0*8192, e = std::min(n, (size_t)b1*8192); for (size_t i = s; i < e; i++) x[i] += y[i]; }); }

  // ---- forward ----
  void forward(Acts& a, int B, int T, const int* ids, bool full) {
    const int d = c.d, H = c.H, hd = d/H, L = c.L, N = B*T; f32* W = w.data(); const f32 sc = 1.f/std::sqrt((f32)hd);
    pf(N, 16, [&](int r0, int r1) { for (int r = r0; r < r1; r++) { const f32* e = W+o_te+(size_t)ids[r]*d; const f32* p = W+o_pe+(size_t)(r%T)*d; f32* x = a.x.data()+(size_t)r*d; for (int i = 0; i < d; i++) x[i] = e[i]+p[i]; } });
    for (int l = 0; l < L; l++) { Layer& y = a.ly[l]; LO& o = lo[l];
      ln_fwd(a.x.data(), W+o.g1, W+o.b1, y.xh1.data(), y.inv1.data(), y.h1.data(), N, d);
      gemm_nn(N, 3*d, d, y.h1.data(), W+o.qkv, y.qkv.data(), false);
      pf(B*H, 1, [&](int t0, int t1) { for (int t = t0; t < t1; t++) { int b = t/H, h = t%H;
        for (int i = 0; i < T; i++) { const f32* q = y.qkv.data()+(size_t)(b*T+i)*3*d+h*hd; f32* p = y.P.data()+((size_t)(b*H+h)*T+i)*T; f32 mx = -1e30f;
          for (int j = 0; j <= i; j++) { const f32* k = y.qkv.data()+(size_t)(b*T+j)*3*d+d+h*hd; f32 s = 0; for (int cc = 0; cc < hd; cc++) s += q[cc]*k[cc]; s *= sc; p[j] = s; mx = std::max(mx, s); }
          f32 sum = 0; for (int j = 0; j <= i; j++) { p[j] = std::exp(p[j]-mx); sum += p[j]; } f32 is = 1.f/sum; for (int j = 0; j <= i; j++) p[j] *= is; for (int j = i+1; j < T; j++) p[j] = 0;
          f32* out = y.ao.data()+(size_t)(b*T+i)*d+h*hd; for (int cc = 0; cc < hd; cc++) out[cc] = 0;
          for (int j = 0; j <= i; j++) { const f32* vv = y.qkv.data()+(size_t)(b*T+j)*3*d+2*d+h*hd; f32 pj = p[j]; for (int cc = 0; cc < hd; cc++) out[cc] += pj*vv[cc]; } } } });
      gemm_nn(N, d, d, y.ao.data(), W+o.o, a.tmp.data(), false); add_inplace(a.x.data(), a.tmp.data(), (size_t)N*d);
      ln_fwd(a.x.data(), W+o.g2, W+o.b2, y.xh2.data(), y.inv2.data(), y.h2.data(), N, d);
      gemm_nn(N, 4*d, d, y.h2.data(), W+o.w1, y.m1.data(), false);
      size_t n4 = (size_t)N*4*d; pf((int)((n4+4095)/4096), 1, [&](int b0, int b1) { size_t s = (size_t)b0*4096, e = std::min(n4, (size_t)b1*4096);
        for (size_t i = s; i < e; i++) { f32 sg = 1.f/(1.f+std::exp(-1.702f*y.m1[i])); y.s[i] = sg; y.a[i] = y.m1[i]*sg; } });
      gemm_nn(N, d, 4*d, y.a.data(), W+o.w2, a.tmp.data(), false); add_inplace(a.x.data(), a.tmp.data(), (size_t)N*d); }
    if (full) { ln_fwd(a.x.data(), W+o_gf, W+o_bf, a.xhf.data(), a.invf.data(), a.hf.data(), N, d); gemm_nt(N, V, d, a.hf.data(), W+o_te, a.logits.data(), false); }
    else { ln_fwd(a.x.data()+(size_t)(T-1)*d, W+o_gf, W+o_bf, a.xhf.data(), a.invf.data(), a.hf.data(), 1, d); gemm_nt(1, V, d, a.hf.data(), W+o_te, a.logits.data(), false); }
  }
  float ce(Acts& a, int N, const int* ys) { // loss; leaves (softmax-onehot)/N in logits
    pf(N, 8, [&](int r0, int r1) { for (int r = r0; r < r1; r++) { f32* p = a.logits.data()+(size_t)r*V; f32 mx = p[0]; for (int i = 1; i < V; i++) mx = std::max(mx, p[i]);
      f32 s = 0; for (int i = 0; i < V; i++) { p[i] = std::exp(p[i]-mx); s += p[i]; } f32 is = 1.f/s; for (int i = 0; i < V; i++) p[i] *= is;
      a.rl[r] = -std::log(std::max(p[ys[r]], 1e-30f)); p[ys[r]] -= 1.f; f32 sN = 1.f/N; for (int i = 0; i < V; i++) p[i] *= sN; } });
    double s = 0; for (int r = 0; r < N; r++) s += a.rl[r]; return (float)(s/N);
  }
  void backward(Acts& a, int B, int T, const int* ids) {
    const int d = c.d, H = c.H, hd = d/H, L = c.L, N = B*T; f32* W = w.data(); f32* G = g.data(); const f32 sc = 1.f/std::sqrt((f32)hd);
    std::fill(g.begin(), g.end(), 0.f); f32* dx = a.dx.data(); f32* tA = a.tA.data(); f32* tB = a.tB.data();
    gemm_nn(N, d, V, a.logits.data(), W+o_te, tB, false); gemm_tn(N, V, d, a.logits.data(), a.hf.data(), G+o_te);
    std::fill(a.dx.begin(), a.dx.end(), 0.f); ln_bwd(tB, a.xhf.data(), a.invf.data(), W+o_gf, G+o_gf, G+o_bf, dx, N, d);
    for (int l = L-1; l >= 0; l--) { Layer& y = a.ly[l]; LO& o = lo[l];
      gemm_tn(N, 4*d, d, y.a.data(), dx, G+o.w2); gemm_nt(N, 4*d, d, dx, W+o.w2, tA, false);
      size_t n4 = (size_t)N*4*d; pf((int)((n4+4095)/4096), 1, [&](int b0, int b1) { size_t s = (size_t)b0*4096, e = std::min(n4, (size_t)b1*4096);
        for (size_t i = s; i < e; i++) { f32 sg = y.s[i]; tA[i] *= sg + 1.702f*y.m1[i]*sg*(1.f-sg); } });
      gemm_tn(N, d, 4*d, y.h2.data(), tA, G+o.w1); gemm_nt(N, d, 4*d, tA, W+o.w1, tB, false);
      ln_bwd(tB, y.xh2.data(), y.inv2.data(), W+o.g2, G+o.g2, G+o.b2, dx, N, d);
      gemm_tn(N, d, d, y.ao.data(), dx, G+o.o); gemm_nt(N, d, d, dx, W+o.o, tB, false);
      std::fill(a.dqkv.begin(), a.dqkv.end(), 0.f); f32* dq_ = a.dqkv.data();
      pf(B*H, 1, [&](int t0, int t1) { std::vector<f32> dp(T); for (int t = t0; t < t1; t++) { int b = t/H, h = t%H;
        for (int i = 0; i < T; i++) { const f32* P = y.P.data()+((size_t)(b*H+h)*T+i)*T; const f32* dao = tB+(size_t)(b*T+i)*d+h*hd; f32 dot2 = 0;
          for (int j = 0; j <= i; j++) { const f32* vv = y.qkv.data()+(size_t)(b*T+j)*3*d+2*d+h*hd; f32 s = 0; for (int cc = 0; cc < hd; cc++) s += dao[cc]*vv[cc]; dp[j] = s; dot2 += P[j]*s; }
          f32* dq = dq_+(size_t)(b*T+i)*3*d+h*hd; const f32* q = y.qkv.data()+(size_t)(b*T+i)*3*d+h*hd;
          for (int j = 0; j <= i; j++) { f32 ds = P[j]*(dp[j]-dot2)*sc; const f32* k = y.qkv.data()+(size_t)(b*T+j)*3*d+d+h*hd; f32* dk = dq_+(size_t)(b*T+j)*3*d+d+h*hd; f32* dv = dq_+(size_t)(b*T+j)*3*d+2*d+h*hd; f32 pj = P[j];
            for (int cc = 0; cc < hd; cc++) { dq[cc] += ds*k[cc]; dk[cc] += ds*q[cc]; dv[cc] += pj*dao[cc]; } } } } });
      gemm_tn(N, d, 3*d, y.h1.data(), a.dqkv.data(), G+o.qkv); gemm_nt(N, d, 3*d, a.dqkv.data(), W+o.qkv, tB, false);
      ln_bwd(tB, y.xh1.data(), y.inv1.data(), W+o.g1, G+o.g1, G+o.b1, dx, N, d); }
    for (int r = 0; r < N; r++) { const f32* xr = dx+(size_t)r*d; f32* te = G+o_te+(size_t)ids[r]*d; f32* pe = G+o_pe+(size_t)(r%T)*d; for (int i = 0; i < d; i++) { te[i] += xr[i]; pe[i] += xr[i]; } }
  }
  float lossOnly(const int* ids, const int* ys, int B, int T) { forward(ta, B, T, ids, true); return ce(ta, B*T, ys); }
  float lossGrad(const int* ids, const int* ys, int B, int T) { forward(ta, B, T, ids, true); float l = ce(ta, B*T, ys); backward(ta, B, T, ids); return l; }
  void adam(float lr) { adamT++; f32 c1 = 1.f-std::pow(.9f,(f32)adamT), c2 = 1.f-std::pow(.99f,(f32)adamT), a = lr/c1, ic2 = 1.f/c2;
    pf((int)((total+4095)/4096), 1, [&](int b0, int b1) { size_t s = (size_t)b0*4096, e = std::min(total, (size_t)b1*4096);
      for (size_t i = s; i < e; i++) { f32 gi = g[i]; f32 mi = m[i] = .9f*m[i]+.1f*gi; f32 vi = v[i] = .99f*v[i]+.01f*gi*gi; w[i] -= a*mi/(std::sqrt(vi*ic2)+1e-7f); } }); }

  // ---- data + trainer thread ----
  bool makeBatch(int B, int T, std::vector<int>& x, std::vector<int>& y) {
    std::lock_guard<std::mutex> lk(dm); bool lv = live; x.resize((size_t)B*T); y.resize((size_t)B*T);
    if (!lv && corpus.size() <= (size_t)T+2) return false;
    std::vector<char> ul(B, 0); size_t nl = 0;
    for (int b = 0; b < B; b++) { bool st = !lv || (corpus.size() > (size_t)T+2 && rf() < mixp); ul[b] = !st; nl += !st; }
    if (nl && lq.size()-lpos < nl*T+1) { if (lq.size() < nl*T+1+(1u<<18)) return false; lpos = rnd() % (lq.size()-nl*T-1); } // starved (e.g. screen off): reuse recent data
    for (int b = 0; b < B; b++) { const uint16_t* src; size_t o; if (ul[b]) { src = lq.data(); o = lpos; lpos += T; } else { src = corpus.data(); o = rnd() % (corpus.size()-T-1); }
      for (int i = 0; i < T; i++) { x[(size_t)b*T+i] = std::min<int>(src[o+i], V-1); y[(size_t)b*T+i] = std::min<int>(src[o+i+1], V-1); } }
    if (lq.size() > (8u<<20)) { size_t cut = std::min(lpos, lq.size()-(4u<<20)); lq.erase(lq.begin(), lq.begin()+cut); lpos -= cut; }
    return true;
  }
  void loop() {
    std::vector<int> x, y;
    while (running) { int B = Bset, T = c.T; float lr = lrset;
      if (!makeBatch(B, T, x, y)) { std::this_thread::sleep_for(std::chrono::milliseconds(5)); continue; }
      while (pausing > 0 && running) std::this_thread::sleep_for(std::chrono::milliseconds(1));
      auto t0 = std::chrono::steady_clock::now(); float loss;
      { std::lock_guard<std::mutex> lk(mu); if (ta.B != B) ta.alloc(B, T, c); loss = lossGrad(x.data(), y.data(), B, T); adam(lr*std::min(1.f, (step+1)/50.f)); }
      if (!std::isfinite(loss)) { std::lock_guard<std::mutex> l2(sm); err = "Loss diverged; lower the learn rate."; running = false; break; }
      step++; seen += (long)B*T; double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now()-t0).count();
      std::lock_guard<std::mutex> l2(sm); lossq.push_back(loss); if (lossq.size() > 5000) lossq.erase(lossq.begin(), lossq.begin()+2500); times.push_back(ms); if (times.size() > 25) times.erase(times.begin()); }
  }
  void start() { if (running || !total) return; if (th.joinable()) th.join(); running = true; th = std::thread([this]{ loop(); }); }
  void stop() { running = false; if (th.joinable()) th.join(); }
  void conf(int B, float lr, bool lv, float mix) { if (B != Bset) { std::lock_guard<std::mutex> l2(sm); times.clear(); } Bset = std::max(1, B); lrset = lr; live = lv; mixp = mix; }
  void feed(const uint8_t* p, size_t nb) { std::lock_guard<std::mutex> lk(dm); size_t n = nb/2, o = lq.size(); lq.resize(o+n); memcpy(lq.data()+o, p, n*2); }
  void setdata(const uint8_t* p, size_t nb, bool first) { std::lock_guard<std::mutex> lk(dm); if (first) corpus.clear(); size_t n = nb/2, o = corpus.size(); corpus.resize(o+n); memcpy(corpus.data()+o, p, n*2); }
  std::string stat() {
    size_t bn; { std::lock_guard<std::mutex> lk(dm); bn = lq.size()-lpos; }
    std::lock_guard<std::mutex> lk(sm); double sps = 0; if (!times.empty()) { auto t = times; std::sort(t.begin(), t.end()); sps = 1000.0/t[t.size()/2]; }
    char b[200]; snprintf(b, sizeof b, "{\"ep\":%d,\"run\":%d,\"step\":%ld,\"seen\":%ld,\"sps\":%.3f,\"buf\":%zu,\"err\":\"%s\",\"l\":[", epoch.load(), running ? 1 : 0, step.load(), seen.load(), sps, bn, err.c_str());
    std::string s = b; for (size_t i = 0; i < lossq.size(); i++) { snprintf(b, sizeof b, "%s%.4f", i ? "," : "", lossq[i]); s += b; } lossq.clear(); return s + "]}";
  }
  int sample(const uint8_t* cb, int nb, float temp, int k) {
    Pause ps(*this); std::lock_guard<std::mutex> lk(mu); if (!total) return 10; int n = nb/2; std::vector<uint16_t> t16(n); if (n) memcpy(t16.data(), cb, n*2); const uint16_t* ctx = t16.data(); if (n > c.T) { ctx += n-c.T; n = c.T; } if (n < 1) return 10;
    std::vector<int> ids(n); for (int i = 0; i < n; i++) ids[i] = std::min<int>(ctx[i], V-1); forward(ia, 1, n, ids.data(), false); const f32* lg = ia.logits.data();
    k = std::max(1, std::min(k, V)); std::vector<int> ix(V); std::iota(ix.begin(), ix.end(), 0); std::partial_sort(ix.begin(), ix.begin()+k, ix.end(), [&](int p, int q) { return lg[p] > lg[q]; });
    std::vector<float> pr(k); float mx = lg[ix[0]], s = 0; for (int i = 0; i < k; i++) { pr[i] = std::exp((lg[ix[i]]-mx)/std::max(temp, 0.01f)); s += pr[i]; }
    float r = rf()*s; for (int i = 0; i < k; i++) { r -= pr[i]; if (r <= 0) return ix[i]; } return ix[0];
  }
  void getw(size_t off, size_t n, void* dst) { Pause ps(*this); std::lock_guard<std::mutex> lk(mu); if (off+n <= total) memcpy(dst, w.data()+off, n*4); }
  void setw(size_t off, size_t n, const void* src) { Pause ps(*this); std::lock_guard<std::mutex> lk(mu); if (off+n <= total) memcpy(w.data()+off, src, n*4); }
  void resetOpt() { Pause ps(*this); std::lock_guard<std::mutex> lk(mu); std::fill(m.begin(), m.end(), 0.f); std::fill(v.begin(), v.end(), 0.f); adamT = 0; }
};

#ifdef TEST_MAIN
#include <cstdio>
int main() {
  Eng e; e.create(2, 16, 2, 8, 300, 1, 1); std::mt19937 rg(5); std::normal_distribution<float> nd(0, 1);
  for (auto& x : e.w) x += .08f*nd(rg); int B = 2, T = 8; std::vector<int> ids(B*T), ys(B*T); for (auto& x : ids) x = rg()%300; for (auto& x : ys) x = rg()%300;
  e.ta.alloc(B, T, e.c); float L0 = e.lossGrad(ids.data(), ys.data(), B, T); std::vector<float> ga = e.g; printf("loss %.4f (ln256=5.545)\n", L0);
  std::vector<std::pair<const char*, size_t>> regs = {{"te", e.o_te}, {"pe", e.o_pe}, {"g1", e.lo[0].g1}, {"b1", e.lo[0].b1}, {"qkv", e.lo[0].qkv}, {"o", e.lo[0].o}, {"g2", e.lo[1].g2}, {"b2", e.lo[1].b2}, {"w1", e.lo[1].w1}, {"w2", e.lo[1].w2}, {"qkv1", e.lo[1].qkv}, {"gf", e.o_gf}, {"bf", e.o_bf}};
  bool ok = true;
  for (auto& r : regs) { double worst = 0; for (int t = 0; t < 6; t++) { size_t i = r.second + rg()%16; if (!strcmp(r.first,"te")) i = e.o_te + (size_t)ids[rg()%16]*16 + rg()%16;
      float eps = 1e-2f, o = e.w[i]; e.w[i] = o+eps; float lp = e.lossOnly(ids.data(), ys.data(), B, T); e.w[i] = o-eps; float lm = e.lossOnly(ids.data(), ys.data(), B, T); e.w[i] = o;
      double num = (lp-lm)/(2*eps), an = ga[i], err = std::fabs(num-an)/(std::fabs(num)+std::fabs(an)+1e-3); worst = std::max(worst, err); }
    printf("%-5s worst rel err %.4f\n", r.first, worst); if (worst > 0.05) ok = false; }
  printf(ok ? "GRADCHECK PASS\n" : "GRADCHECK FAIL\n");
  Eng f; f.create(4, 128, 4, 128, 256, 2, 1); B = 8; T = 128; std::vector<int> x(B*T), y(B*T); for (auto& q : x) q = rg()%256; for (auto& q : y) q = rg()%256; f.ta.alloc(B, T, f.c);
  f.lossGrad(x.data(), y.data(), B, T); f.adam(.003f); auto t0 = std::chrono::steady_clock::now(); for (int i = 0; i < 3; i++) { f.lossGrad(x.data(), y.data(), B, T); f.adam(.003f); }
  printf("Chat preset B=8 single thread: %.0f ms/step\n", std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now()-t0).count()/3);
  { Eng k; k.create(6, 192, 6, 256, 4096, 2, 1); B = 8; T = 256; std::vector<int> a(B*T), b(B*T); for (auto& q : a) q = rg()%4096; for (auto& q : b) q = rg()%4096; k.ta.alloc(B, T, k.c);
    k.lossGrad(a.data(), b.data(), B, T); k.adam(.003f); auto t1 = std::chrono::steady_clock::now(); k.lossGrad(a.data(), b.data(), B, T); k.adam(.003f);
    printf("Words preset (6x192, V=4096, T=256, B=8) single thread: %.0f ms/step, %zu weights\n", std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now()-t1).count(), k.total); }
  // learning sanity: repeat a pattern, loss must fall
  Eng h; h.create(2, 32, 2, 16, 256, 3, 1); std::vector<int> px(4*16), py(4*16); h.ta.alloc(4, 16, h.c); const char* pat = "hello world. hello world. hello world. hello world. hello world.";
  for (int b = 0; b < 4; b++) for (int i = 0; i < 16; i++) { px[b*16+i] = pat[b*3+i]; py[b*16+i] = pat[b*3+i+1]; }
  float first = 0, last = 0; for (int s = 0; s < 150; s++) { float l = h.lossGrad(px.data(), py.data(), 4, 16); h.adam(.01f*std::min(1.f,(s+1)/20.f)); if (!s) first = l; last = l; }
  printf("learning: loss %.3f -> %.3f %s\n", first, last, last < first*0.4f ? "PASS" : "FAIL");
}
#endif

#ifdef LLM_JNI
static Eng* E() { static Eng e; return &e; }
extern "C" {
#define J(n) Java_com_example_llmlab_Native_##n
JNIEXPORT void JNICALL J(create)(JNIEnv*, jobject, jint L, jint d, jint H, jint T, jint Vv, jint seed, jint thr) { E()->create(L, d, H, T, Vv, seed, thr); }
JNIEXPORT void JNICALL J(setThreads)(JNIEnv*, jobject, jint n) { Eng::Pause ps(*E()); std::lock_guard<std::mutex> lk(E()->mu); E()->pool.start(n); }
JNIEXPORT void JNICALL J(setState)(JNIEnv*, jobject, jlong s, jlong n) { E()->step = s; E()->seen = n; }
JNIEXPORT void JNICALL J(conf)(JNIEnv*, jobject, jint B, jfloat lr, jboolean lv, jfloat mix) { E()->conf(B, lr, lv, mix); }
JNIEXPORT void JNICALL J(start)(JNIEnv*, jobject) { E()->start(); }
JNIEXPORT void JNICALL J(stop)(JNIEnv*, jobject) { E()->stop(); }
JNIEXPORT void JNICALL J(resetOpt)(JNIEnv*, jobject) { E()->resetOpt(); }
JNIEXPORT void JNICALL J(feed)(JNIEnv* env, jobject, jbyteArray b) { jsize n = env->GetArrayLength(b); jbyte* p = env->GetByteArrayElements(b, nullptr); E()->feed((uint8_t*)p, n); env->ReleaseByteArrayElements(b, p, JNI_ABORT); }
JNIEXPORT void JNICALL J(data)(JNIEnv* env, jobject, jbyteArray b, jboolean first) { jsize n = env->GetArrayLength(b); jbyte* p = env->GetByteArrayElements(b, nullptr); E()->setdata((uint8_t*)p, n, first); env->ReleaseByteArrayElements(b, p, JNI_ABORT); }
JNIEXPORT jstring JNICALL J(stat)(JNIEnv* env, jobject) { return env->NewStringUTF(E()->stat().c_str()); }
JNIEXPORT jint JNICALL J(gen)(JNIEnv* env, jobject, jbyteArray b, jfloat t, jint k) { jsize n = env->GetArrayLength(b); jbyte* p = env->GetByteArrayElements(b, nullptr); int r = E()->sample((uint8_t*)p, n, t, k); env->ReleaseByteArrayElements(b, p, JNI_ABORT); return r; }
JNIEXPORT jint JNICALL J(wsize)(JNIEnv*, jobject) { return (jint)E()->total; }
JNIEXPORT jbyteArray JNICALL J(getW)(JNIEnv* env, jobject, jint off, jint len) { std::vector<f32> t(len); E()->getw(off, len, t.data()); jbyteArray r = env->NewByteArray(len*4); env->SetByteArrayRegion(r, 0, len*4, (jbyte*)t.data()); return r; }
JNIEXPORT void JNICALL J(setW)(JNIEnv* env, jobject, jint off, jbyteArray b) { jsize n = env->GetArrayLength(b); jbyte* p = env->GetByteArrayElements(b, nullptr); E()->setw(off, n/4, p); env->ReleaseByteArrayElements(b, p, JNI_ABORT); }
}
#endif
