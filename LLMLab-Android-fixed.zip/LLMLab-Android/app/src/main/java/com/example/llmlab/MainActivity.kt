package com.example.llmlab

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.WindowManager
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); chooser = null
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val prefs by lazy { getSharedPreferences("llm", Context.MODE_PRIVATE) }

    inner class Bridge {
        // model -> filesDir (app data, survives); corpus -> cacheDir (regenerable); exports -> app external files
        private fun target(k: String): File = when {
            k == "model" -> File(filesDir, "model.bin")
            k == "corpus" -> File(cacheDir, "corpus.bin")
            k.startsWith("export:") -> File(getExternalFilesDir(null), "exports").apply { mkdirs() }
                .let { File(it, k.removePrefix("export:").replace(Regex("[^A-Za-z0-9._-]"), "_")) }
            else -> throw IllegalArgumentException("bad key")
        }
        @JavascriptInterface fun write(k: String, i: Int, b64: String, last: Boolean) {
            val f = target(k); val tmp = File(f.path + ".tmp"); if (i == 0) tmp.delete()
            tmp.appendBytes(Base64.decode(b64, Base64.NO_WRAP))
            if (last) { f.delete(); tmp.renameTo(f) }
        }
        @JavascriptInterface fun size(k: String): Long = target(k).let { if (it.exists()) it.length() else -1L }
        @JavascriptInterface fun read(k: String, off: Long, len: Int): String =
            RandomAccessFile(target(k), "r").use { r ->
                r.seek(off); val b = ByteArray(minOf(len.toLong(), r.length() - off).toInt()); r.readFully(b)
                Base64.encodeToString(b, Base64.NO_WRAP)
            }
        @JavascriptInterface fun memInfo(): String {
            val am = getSystemService(ActivityManager::class.java); val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            return """{"total":${mi.totalMem},"avail":${mi.availMem},"heap":${am.largeMemoryClass}}"""
        }
        // ---- background training (optional foreground service) ----
        @JavascriptInterface fun getBg(): Boolean = prefs.getBoolean("bg", false)
        @JavascriptInterface fun setBg(on: Boolean) { prefs.edit().putBoolean("bg", on).apply() }
        @JavascriptInterface fun bgStart() { runOnUiThread {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            try { startForegroundService(Intent(this@MainActivity, TrainService::class.java)) } catch (e: Exception) { }
        } }
        @JavascriptInterface fun bgStop() { runOnUiThread { stopService(Intent(this@MainActivity, TrainService::class.java)) } }
        @JavascriptInterface fun bgText(t: String) { TrainService.setText(this@MainActivity, t) }
        @JavascriptInterface fun bgBattery() { runOnUiThread {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:$packageName"))) }
            catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { } }
        } }
        // ---- native C++ engine bridge ----
        @JavascriptInterface fun nok(): Boolean = Native.ok
        @JavascriptInterface fun ninit(L: Int, d: Int, H: Int, T: Int, V: Int, seed: Int, thr: Int) = Native.create(L, d, H, T, V, seed, thr)
        @JavascriptInterface fun nthr(n: Int) = Native.setThreads(n)
        @JavascriptInterface fun nstate(step: Double, seen: Double) = Native.setState(step.toLong(), seen.toLong())
        @JavascriptInterface fun nconf(B: Int, lr: Double, live: Boolean, mix: Double) = Native.conf(B, lr.toFloat(), live, mix.toFloat())
        @JavascriptInterface fun nstart() = Native.start()
        @JavascriptInterface fun nstop() = Native.stop()
        @JavascriptInterface fun nreset() = Native.resetOpt()
        @JavascriptInterface fun nfeed(b64: String) = Native.feed(Base64.decode(b64, Base64.NO_WRAP))
        @JavascriptInterface fun ndata(first: Boolean, b64: String) = Native.data(Base64.decode(b64, Base64.NO_WRAP), first)
        @JavascriptInterface fun nstat(): String = Native.stat()
        @JavascriptInterface fun ngen(b64: String, temp: Double, k: Int): Int = Native.gen(Base64.decode(b64, Base64.NO_WRAP), temp.toFloat(), k)
        @JavascriptInterface fun nwsize(): Int = Native.wsize()
        @JavascriptInterface fun ngetw(off: Int, len: Int): String = Base64.encodeToString(Native.getW(off, len), Base64.NO_WRAP)
        @JavascriptInterface fun nsetw(off: Int, b64: String) = Native.setW(off, Base64.decode(b64, Base64.NO_WRAP))
        // ---- native checkpoint (weights never pass through the WebView) ----
        private val saver = Executors.newSingleThreadExecutor()
        @Volatile private var saving = false
        private fun modelFile() = File(filesDir, "model.bin")
        private fun headLen(f: File): Int = try {
            if (!f.exists() || f.length() < 4) -1 else RandomAccessFile(f, "r").use { r ->
                val b = ByteArray(4); r.readFully(b); val hl = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int
                if (hl <= 0 || hl > (1 shl 24) || 4L + hl > r.length()) -1 else hl }
        } catch (e: Exception) { -1 }
        @JavascriptInterface fun nmeta(h: String) { Native.hdr = if (h.isEmpty()) null else h.toByteArray(Charsets.UTF_8) }
        @JavascriptInterface fun nsave(h: String): Boolean {
            if (saving) return false
            Native.hdr = h.toByteArray(Charsets.UTF_8); saving = true
            saver.execute { try { Native.saveTo(modelFile()) } finally { saving = false } }
            return true
        }
        @JavascriptInterface fun nsaving(): Boolean = saving
        @JavascriptInterface fun nsaveok(): Boolean = Native.saveOk
        @JavascriptInterface fun nhead(): String {
            val f = modelFile(); val hl = headLen(f); if (hl < 0) return ""
            return try { RandomAccessFile(f, "r").use { r -> r.seek(4); val h = ByteArray(hl); r.readFully(h); String(h, Charsets.UTF_8) } } catch (e: Exception) { "" }
        }
        @JavascriptInterface fun nloadw(): Boolean { val f = modelFile(); val hl = headLen(f); return hl >= 0 && Native.loadW(f.path, 4 + hl) }
        @JavascriptInterface fun getBudget(): Int = prefs.getInt("mb", 1024)
        @JavascriptInterface fun setBudget(mb: Int) { prefs.edit().putInt("mb", mb).apply() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // a fresh page cannot control a trainer left running by a previous session: stop it, never leave it orphaned
        Native.halt(File(filesDir, "model.bin"), false); stopService(Intent(this, TrainService::class.java))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this).also { setContentView(it) }
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try { pick.launch(p.createIntent()); true } catch (e: Exception) { chooser = null; false }
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onStop() {
        super.onStop()
        // leaving the screen: unless "keep training with screen off" is on, stop the trainer and checkpoint
        if (!prefs.getBoolean("bg", false)) Native.halt(File(filesDir, "model.bin"), true)
    }
    override fun onDestroy() {
        if (!isChangingConfigurations) { Native.halt(File(filesDir, "model.bin"), true); stopService(Intent(this, TrainService::class.java)) }
        super.onDestroy()
    }
    override fun onPause() { super.onPause(); web.evaluateJavascript("window.onNativePause&&window.onNativePause()", null) }
}
