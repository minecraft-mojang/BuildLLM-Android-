package com.example.llmlab

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.io.File

class TrainService : Service() {
    companion object {
        const val CH = "train"
        @Volatile var text = "Training..."
        @Volatile var up = false
        fun build(c: Context): Notification {
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            return Notification.Builder(c, CH).setContentTitle("LLM Lab training").setContentText(text)
                .setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi)
                .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(c, android.R.drawable.ic_menu_close_clear_cancel), "Stop training", PendingIntent.getService(c, 1, Intent(c, TrainService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)).build()).build()
        }
        fun setText(c: Context, t: String) {
            text = t
            if (up) c.getSystemService(NotificationManager::class.java).notify(1, build(c))
        }
    }
    private var wl: PowerManager.WakeLock? = null
    override fun onBind(i: Intent?): IBinder? = null
    private fun haltAll() { Native.halt(File(filesDir, "model.bin"), true); up = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
    override fun onTaskRemoved(rootIntent: Intent?) { haltAll(); super.onTaskRemoved(rootIntent) }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { haltAll(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CH, "Training", NotificationManager.IMPORTANCE_LOW))
        val n = build(this)
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        if (wl == null) wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "llmlab:train")
            .apply { setReferenceCounted(false); acquire(12 * 3600 * 1000L) }
        up = true
        return START_NOT_STICKY
    }
    override fun onDestroy() { up = false; wl?.let { if (it.isHeld) it.release() }; wl = null; super.onDestroy() }
}
