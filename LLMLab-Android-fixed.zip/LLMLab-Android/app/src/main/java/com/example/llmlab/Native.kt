package com.example.llmlab

object Native {
    var ok = false
    init { try { System.loadLibrary("llmnative"); ok = true } catch (e: Throwable) { } }
    external fun create(L: Int, d: Int, H: Int, T: Int, V: Int, seed: Int, threads: Int)
    external fun setThreads(n: Int)
    external fun setState(step: Long, seen: Long)
    external fun conf(B: Int, lr: Float, live: Boolean, mix: Float)
    external fun start()
    external fun stop()
    external fun resetOpt()
    external fun feed(b: ByteArray)
    external fun data(b: ByteArray, first: Boolean)
    external fun stat(): String
    external fun gen(ctx: ByteArray, temp: Float, k: Int): Int
    external fun wsize(): Int
    external fun getW(off: Int, len: Int): ByteArray
    external fun setW(off: Int, b: ByteArray)
    external fun saveW(path: String, hdr: ByteArray): Boolean
    external fun loadW(path: String, off: Int): Boolean
    // header JSON of the model currently in the engine (set by the page); null = nothing worth saving
    @Volatile var hdr: ByteArray? = null
    @Volatile var saveOk = true
    @Synchronized fun saveTo(f: java.io.File): Boolean {
        val h = hdr ?: return false
        saveOk = try { saveW(f.path, h) } catch (e: Throwable) { false }
        return saveOk
    }
    /** Stop the trainer thread and (optionally) checkpoint, so nothing keeps running unseen. */
    fun halt(f: java.io.File, save: Boolean) {
        if (!ok) return
        try { stop(); if (save) saveTo(f) } catch (e: Throwable) { }
    }
}
