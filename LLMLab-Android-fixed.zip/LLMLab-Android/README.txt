1. Open this folder in Android Studio (Koala+), let Gradle sync, press Run on the Oppo Pad (USB debugging on). Or Build > Build APK.
2. Optional, for offline use: put tf.min.js and tf-backend-webgpu.min.js (from cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/ and
   .../tfjs-backend-webgpu@4.22.0/dist/) into app/src/main/assets/. Without them the app loads them from the CDN (needs internet).
Storage: model -> /data/data/com.example.llmlab/files/model.bin ; corpus -> .../cache/corpus.bin ; exports -> Android/data/com.example.llmlab/files/exports/
